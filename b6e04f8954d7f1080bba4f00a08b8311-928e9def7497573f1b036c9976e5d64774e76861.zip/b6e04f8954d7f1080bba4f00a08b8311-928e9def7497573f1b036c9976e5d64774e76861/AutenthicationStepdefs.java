package Skitraj;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AutenthicationStepdefs {
    @Given("I open Google Chrome")
    public void IopenGoogleChrome(){
        System.out.println("Chrome is Opened");
    }
    @When("Entered website address First Time")
    public void EnteredWebsiteAddressFirstTime(){
        System.out.println("Site is Opened");
    }
    @Then("I can see cookies files and button")
    public void IcanSeeCookiesFilesAndButton(){
        System.out.println("I can see correct Page");
    }


    @Given(": I open Google Chrome")
    public void iOpenGoogleChrome() {

    }

    @When(": Entered website address First Time")
    public void enteredWebsiteAddressFirstTime() {

    }

    @Then(": I can see cookies files and button")
    public void iCanSeeCookiesFilesAndButton() {

    }
}
